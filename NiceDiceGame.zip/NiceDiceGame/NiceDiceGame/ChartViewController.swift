//
//  ChartViewController.swift
//  NiceDiceGame
//
//  Created by IACD-020 on 2022/05/14.
//

import UIKit
import Charts

class ChartViewController: UIViewController {
    
   public static var occurences2:[Int:Int] = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        print(DiceHistoryViewController.diceHistory2.count)
        
        createChart(dic: ChartViewController.occurences2)
    }
    
    func createChart(dic: Dictionary<Int,Int>){
          
          //self.barChart.inputViewController?.dismiss(animated: true)
          
          let barChart = BarChartView(frame: CGRect(x: 0, y: 0, width: view.frame.size.width, height: view.frame.size.width) )
          
          var entries = [BarChartDataEntry]()
          var count = 0.0
        
          dic.forEach {x,y in
              entries.append(BarChartDataEntry(x: Double(x), y: Double(y)
                                              ))
                             
          //print(entries)
            // print(count)
              //print(entries)
              print(ChartViewController.occurences2)
          }
          
          
          let set = BarChartDataSet(entries: entries, label: "Dice Rolls")
        set.colors = ChartColorTemplates.material()
          let data = BarChartData(dataSet: set)
          
          barChart.data = data
       
                             
         view.addSubview(barChart)
          barChart.center = view.center
          
          
          
          
      }
}

//
//  ViewController.swift
//  NiceDiceGame
//
//  Created by IACD-020 on 2022/05/06.
//

import UIKit
import Charts

class ViewController: UIViewController {

    @IBOutlet weak var outputText: UITextView!
    @IBOutlet weak var image2: UIImageView!
    @IBOutlet weak var image1: UIImageView!
    
    var diceImages = ["dice1","dice2","dice3","dice4","dice5","dice6"]
    var dice = [UIImage]()
    var score = 0
    var diceHistory = [Int]()
    var dicetotal: [Int] = []
    var occurrences: [Int : Int] = [:]
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        for die in diceImages {
            dice.append(UIImage(named: die)!)
        }
    }

    @IBAction func rollTapped(_ sender: Any) {
        let randomNr1 = Int.random(in: 0..<6)
        let randomNr2 = Int.random(in: 0..<6)
        let history1 = randomNr1+1
        let history2 = randomNr2+1
        image1.image = UIImage(named: diceImages[randomNr1])
        image2.image = UIImage(named: diceImages[randomNr2])
        diceHistory.append(history1)
        diceHistory.append(history2)
        
        if ((randomNr1+1) + (randomNr2+1)) == 7 {
            score+=1
            outputText.text = "You got a 7!!! \nYour score is \(score) "
            resultAlert(title: "Win!!!")
        }else{
            outputText.text = "You lost☹️ \nYou need a 7 to win \nYour score is \(score) "
        }
        
        let total = randomNr1 + 1 + randomNr2 + 1
                dicetotal.append(total)
        
        
       
      
       
        
    }
    
    func resultAlert(title:String){
        let message = "You got a 7🎰"
        let ac = UIAlertController(title: title, message: message, preferredStyle: .actionSheet)
        
        ac.addAction(UIAlertAction(title: "Play again", style: .default, handler: { (_) in
            
            
        }))
        self.present(ac, animated: true)
    }
    
 
    @IBAction func diceHistoryTapped(_ sender: UIButton) {
     
        
        DiceHistoryViewController.diceHistory2 = diceHistory
        DiceHistoryViewController.diceTotal = dicetotal
        
    }
    
    
    @IBAction func showChartTapped(_ sender: Any) {
        
        for number in dicetotal {
                    if let value = occurrences[number] {
                        occurrences[number] = value + 1
                       
                    } else {
                        occurrences[number] = 1
                    }
                }
        
        ChartViewController.occurences2 = occurrences
        print(occurrences)
             
    }
    
    /*
    func createChart(dic: Dictionary<Int,Int>){
            
            //self.ChartViewController.inputViewController?.dismiss(animated: true)
            
            let barChart = BarChartView(frame: CGRect(x: 0, y: 0, width: view.frame.size.width, height: view.frame.size.width) )
            
            var entries = [BarChartDataEntry]()
            var count = 0.0
            dic.forEach {x,y in
                entries.append(BarChartDataEntry(x: Double(x), y: Double(y)
                                                ))
                               
            print(entries)
              //  print(count)
                print(entries)
            }
            
            
            let set = BarChartDataSet(entries: entries, label: "Dice Rolls")

            let data = BarChartData(dataSet: set)
            
            barChart.data = data
         
                               
           view.addSubview(barChart)
            barChart.center = view.center
            
            
            
            
        }
       */
}


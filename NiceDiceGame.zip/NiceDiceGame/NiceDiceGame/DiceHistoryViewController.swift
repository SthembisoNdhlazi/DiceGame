//
//  DiceHistoryViewController.swift
//  NiceDiceGame
//
//  Created by IACD-020 on 2022/05/11.
//

import UIKit

class DiceHistoryViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    public static var diceHistory2 = [Int]()
    public static var diceTotal = [Int]()
    

    @IBOutlet weak var tableOutput: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
    
        self.tableOutput.dataSource = self
        self.tableOutput.delegate = self
        self.tableOutput.isScrollEnabled = true
        self.tableOutput.reloadData()
        
        title = "Dice History"
        //print(DiceHistoryViewController.diceHistory2.count)
    }
    
    func tableView(_ tableOutput: UITableView,numberOfRowsInSection section: Int) -> Int {
            
      
        return DiceHistoryViewController.diceTotal.count
        
           
    }
                
    func tableView(_ tableOutput: UITableView,cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let cell = UITableViewCell()
        cell.textLabel?.text = String("Dice Total: \(DiceHistoryViewController.diceTotal[indexPath.row])")
         
    return cell
    }
  

}
